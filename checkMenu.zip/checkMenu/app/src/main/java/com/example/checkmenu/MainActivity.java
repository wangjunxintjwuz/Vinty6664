package com.example.checkmenu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.lang.annotation.Documented;
import java.util.HashMap;
import java.util.HashSet;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button dc = findViewById(R.id.button_dc);
        final TextView menu = (TextView) findViewById(R.id.menu_window);

        dc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menu.setText("DC menu");
            }

        });
        
        final Button erd = findViewById(R.id.button_erd);

        erd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menu.setText("Erdman menu");
            }

        });

        final Button nd = findViewById(R.id.button_nd);

        nd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menu.setText("ND menu");
            }

        });
    }
}
